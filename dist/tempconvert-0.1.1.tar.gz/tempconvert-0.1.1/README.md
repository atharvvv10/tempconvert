# tempconvert

A simple Python package to convert temperature between Celsius and Fahrenheit.

## Usage

```python
from tempconvert import celsius_to_fahrenheit, fahrenheit_to_celsius

print(celsius_to_fahrenheit(0))  # 32.0
print(fahrenheit_to_celsius(212))  # 100.0
